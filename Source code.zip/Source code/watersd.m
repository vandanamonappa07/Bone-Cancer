function watersd(x)
f=x;
binary_w=im2bw(f,graythresh(f));
binary_wc=~binary_w;
distance=bwdist(binary_wc);
wats=watershed(-distance);
w=wats==0;
rf=binary_w&~w;
figure,imshow(f),title('Original Image');
%figure,imshow(bw),title('Negative Image');
%figure,imshow(ws),title('Watershed - Distance Transform');
%figure,imshow(rf),title('Superimposed - Watershed and original image');

h=fspecial('sobel');
final_d=im2double(f);
square=sqrt(imfilter(final_d,h,'replicate').^2+imfilter(final_d,h','replicate').^2);
square_oc=imclose(imopen(square,ones(3,3)),ones(3,3));
wattsd=watershed(square_oc);
wag=wattsd==0;
rfffg=f;
rfffg(wag)=255;
%figure,imshow(wsd),title('Watershed - Gradient');
%figure,imshow(rf),title('Superimposed - Watershed and original image');

imga=imextendedmin(f,20);
Limit=watershed(bwdist(imga));
%figure,imshow(Lim),title('Watershed - Marker Controlled');
em=Limit==0;
refmin=imimposemin(square,imga|em);
waeesdmin=watershed(refmin);
figure,imshow(refmin),title('Watershed - Gradient and Marker Controlled');
rfgm=f;
rfgm(waeesdmin==0)=255;
figure,imshow(rfgm),title('Superimposed - Watershed (GM) and original image');



im=rgb2gray(rfgm);
threshold = graythresh(im); 
% apply threshold to segment light grains from dark background

BW = im2bw(im, threshold);
ed=edge(BW,'canny');
[L,N] =  bwlabel(ed);
figure(10);imshow(ed);
figure(11);imshow(L);title('Edge detection');



stats = regionprops(L, 'Centroid','MajorAxisLength','MinorAxisLength','Perimeter')
list= [stats(:).Perimeter];
count=0;
m=mean2(list);
for i= 1:N
    list(i)
    
    if( list(i)>m)
                count=count+1;
    end
end
count
irr=0;
PER=(100*count)/N

if(count>50)
    irr=1;
end
irr

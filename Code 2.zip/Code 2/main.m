

function varargout = main(varargin)
% MAIN MATLAB code for main.fig
%      MAIN, by itself, creates a new MAIN or raises the existing
%      singleton*.
%
%      H = MAIN returns the handle to a new MAIN or the handle to
%      the existing singleton*.
%
%      MAIN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN.M with the given input arguments.
%
%      MAIN('Property','Value',...) creates a new MAIN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help main

% Last Modified by GUIDE v2.5 09-Jan-2017 14:47:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_OpeningFcn, ...
                   'gui_OutputFcn',  @main_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main is made visible.
function main_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main (see VARARGIN)

% Choose default command line output for main
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = main_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%{
[f p] = uigetfile('*.jpg');
c=imread([p f]);
%}
global  c f pink_osteiod dark_nuclie light_nuclie;
axes(handles.axes1),imshow(c), title('Original Image');

colors = [  0.25 0.25 0.9;  % dark blue
            0.5 0.5 1;  % light blue
            1 0.5 1;% pink
];


% % You can change the colors        
% colors = [  0 0 1;    % red
%             1 1 0;    % yellow
%             1 0 0;    % blue
%             1 1 1];   % white
c=imresize(c,[350 350]);
figure(4),imshow(c), title('original image');
cform = makecform('srgb2lab');
lab_I = applycform(c,cform);
ab = double(lab_I(:,:,2:3));
nrows = size(ab,1);
ncols = size(ab,2);
ab = reshape(ab,nrows*ncols,2);
nColors = 3;
list = double(reshape(c, [], 3)) / 255;
[~,idx] = pdist2(colors, list, 'euclidean', 'smallest', 1);
% IDX contains the indices to the nearest element
pixel_labels = reshape(idx,nrows,ncols)
L = lab_I(:,:,1);
%-----------------------------------------------------------------------
% obtain index of color 3
pink_idx = find((pixel_labels == 3));
L_pink = L(pink_idx);
is_pink = im2bw(L_pink,graythresh(L_pink));
osteoid_labels = repmat(uint8(0),[nrows ncols]);
osteoid_labels(pink_idx(is_pink==false)) = 1;
osteoid_labels = repmat(osteoid_labels,[1 1 3]);
pink_osteiod = c;
pink_osteiod(osteoid_labels ~= 1) = 0;
pink_osteiod=imresize(pink_osteiod,[350 350]);
%find maximum value in an array 
gry=rgb2gray(pink_osteiod);
se = strel('disk',1);
erodedI = imerode(gry,se);
labels = repmat(uint8(0),[nrows ncols]);
labels(erodedI~=0) = 1;
labels = repmat(labels,[1 1 3]);
pink_osteiod(labels ~= 1) = 0;
axes(handles.axes2)
imshow(pink_osteiod), title('Calcification of osteiod');
figure(1),imshow(pink_osteiod), title('Calcification of osteiod');
%-------------------------------------------------------------------------------------------------
% obtain index of color 1 dark blue


blue_idx = find(pixel_labels == 1);

L_blue = L(blue_idx);
is_blue= im2bw(L_blue,graythresh(L_blue));
dark_nuclie_labels = repmat(uint8(0),[nrows ncols]);
dark_nuclie_labels(blue_idx(is_blue==false)) = 1;
dark_nuclie_labels = repmat(dark_nuclie_labels,[1 1 3]);
dark_nuclie = c;
dark_nuclie(dark_nuclie_labels ~= 1) = 0;
dark_nuclie=imresize(dark_nuclie,[350 350]);
%find maximum value in an array 
axes(handles.axes3),
imshow(dark_nuclie), title('Hyper-chromatic nuclie');
figure(2),imshow(dark_nuclie), title('Hyper-chromatic nuclie');
%-------------------------------------------------------------------------


% obtain index of color 1 dark blue
lightblue_idx1 = find(pixel_labels == 2);
id=find(pixel_labels == 1);
lightblue_idx=union(lightblue_idx1,id);
lightblue_idx=sort(lightblue_idx);
L_lightblue = L(lightblue_idx);
is_lightblue= im2bw(L_lightblue,graythresh(L_lightblue));
light_nuclie_labels = repmat(uint8(0),[nrows ncols]);
light_nuclie_labels(lightblue_idx(is_lightblue==false)) = 1;
light_nuclie_labels = repmat(light_nuclie_labels,[1 1 3]);
light_nuclie = c;
light_nuclie(light_nuclie_labels ~= 1) = 0;
light_nuclie=imresize(light_nuclie,[350 350]);
%find maximum value in an array 
axes(handles.axes4),imshow(light_nuclie), title('light nuclie');
figure(3),imshow(light_nuclie), title('light nuclie');
%{
fea1();
fea2();
fea3();
%}
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
normalize


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fea
function varargout = main_gui(varargin)
% MAIN_GUI M-file for main_gui.fig
%      MAIN_GUI, by itself, creates a new MAIN_GUI or raises tI existing
%      singleton*.
%
%      H = MAIN_GUI returns tI handle to a new MAIN_GUI or tI handle to
%      tI existing singleton*.
%
%      MAIN_GUI('CALLBACK',hObject,eventData,handles,...) calls tI local
%      function named CALLBACK in MAIN_GUI.M with tI given input arguments.
%
%      MAIN_GUI('Property','Value',...) creates a new MAIN_GUI or raises tI
%      existing singleton*.  Starting from tI left, property value pairs are
%      applied to tI GUI before main_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit tI above text to modify tI response to Ilp main_gui

% Last Modified by GUIDE v2.5 04-Jan-2015 12:20:35

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @main_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main_gui is made visible.
function main_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main_gui (see VARARGIN)

% Choose default command line output for main_gui
handles.output = hObject;
% F=get(handles.uipanel1,'Position');
% P=1./F;
% ah=axes('unit','normalized','position',[0.029 0.227 0.941 0.545]);
% bg=imread('h.jpg'); imagesc(bg);
% set(ah,'handlevisibility','off','visible','off');
% uistack(ah,'bottom');
% % Update handles structure
guidata(hObject, handles);

% UIWAIT makes main_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);
% set(gcf,'position',[0 100 300 500]);

% --- Outputs from this function are returned to tI command line.
function varargout = main_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = hObject;
% a = imread('h.jpg');
% b=imresize(a,.5);
% set(handles.input, 'CData', b);
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in input.
function input_Callback(hObject, eventdata, handles)
% hObject    handle to input (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I 
[f p] = uigetfile('*.jpg');
I=imread([p f]);
axes(handles.axes1)
% figure(1);
imshow(I);title('original Image');
gthresh = graythresh(I);
% axes(handles.axes1);
fprintf('Threshold value of the original image is : %f \n', gthresh);



% --- Executes on button press in preprocess.
function preprocess_Callback(hObject, eventdata, handles)
% hObject    handle to preprocess (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_gui1


% --- Executes on button press in edge.
function edge_Callback(hObject, eventdata, handles)
% hObject    handle to edge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global filt
ed=edge(filt,'canny');
axes(handles.axes1)
% figure(5);
imshow(ed);title('Canny Filter');


% --- Executes on button press in binary.
function binary_Callback(hObject, eventdata, handles)
% hObject    handle to binary (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global gr bw
bw=im2bw(gr);
% figure(6);
axes(handles.axes1)
imshow(bw);title('Binary Image')


% --- Executes on button press in binary_contour.
function binary_contour_Callback(hObject, eventdata, handles)
% hObject    handle to binary_contour (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% figure(7);
global bw
axes(handles.axes1)
imshow(bw);
hold on;
boundaries = bwboundaries(bw);
numberOfBoundaries = size(boundaries);
for k = 1 : numberOfBoundaries
	    thisBoundary= boundaries{k};
        pause(0.1)
        plot(thisBoundary(:,2), thisBoundary(:,1), 'g', 'LineWidth',1);
end


% --- Executes on button press in contour_segmentation.
function contour_segmentation_Callback(hObject, eventdata, handles)
% hObject    handle to contour_segmentation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global imres bw
% figure(8),
imshow(imres);title('Countour Base Image Segment');
hold on;
boundaries = bwboundaries(bw);
Boundary = size(boundaries);
for k = 1 : Boundary
	    thisBoundary= boundaries{k};
        pause(0.1)
        plot(thisBoundary(:,2), thisBoundary(:,1), 'g', 'LineWidth', 1);
end
% thresh_of_boundaries = graythresh(boundaries);
% fprintf('Threshold value of Boundaries = %f',thresh_of_boundaries);



% --- Executes on button press in segmentation.
function segmentation_Callback(hObject, eventdata, handles)
% hObject    handle to segmentation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I
im = double(I);
[back_masked_image] = separate_backgd(im,1);
% figure;
axes(handles.axes1)
imshow(uint8(back_masked_image.*im));
title('Backgroung Extraction');
watersd(uint8(back_masked_image.*im));


% --- Executes on button press in Clustering.
function Clustering_Callback(hObject, eventdata, handles)
% hObject    handle to Clustering (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% I = imread('Istain.png');
main_gui2
 
 


% --- Executes on button press in feature.
function feature_Callback(hObject, eventdata, handles)
% hObject    handle to feature (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_gui3


% --- Executes on button press in svm_class.
function svm_class_Callback(hObject, eventdata, handles)
% hObject    handle to svm_class (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_gui4


% --- Executes on button press in enhancement.
function enhancement_Callback(hObject, eventdata, handles)
% hObject    handle to enhancement (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_gui6


% --- Executes during object creation, after setting all properties.
function uipanel1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

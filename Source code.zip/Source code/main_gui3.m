function varargout = main_gui3(varargin)
% MAIN_GUI3 M-file for main_gui3.fig
%      MAIN_GUI3, by itself, creates a new MAIN_GUI3 or raises the existing
%      singleton*.
%
%      H = MAIN_GUI3 returns the handle to a new MAIN_GUI3 or the handle to
%      the existing singleton*.
%
%      MAIN_GUI3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAIN_GUI3.M with the given input arguments.
%
%      MAIN_GUI3('Property','Value',...) creates a new MAIN_GUI3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before main_gui3_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to main_gui3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help main_gui3

% Last Modified by GUIDE v2.5 27-Nov-2014 16:49:38

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @main_gui3_OpeningFcn, ...
                   'gui_OutputFcn',  @main_gui3_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before main_gui3 is made visible.
function main_gui3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to main_gui3 (see VARARGIN)

% Choose default command line output for main_gui3
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes main_gui3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = main_gui3_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in lbp.
function lbp_Callback(hObject, eventdata, handles)
% hObject    handle to lbp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global filt
LBPimg = LBP((filt), [2,3]); 
figure('Name','LBP Feature','NumberTitle','Off')
imshow(LBPimg);
LBPfeature=imhist(LBPimg);
set(handles.uitable1,'data',LBPfeature')
LBPfea = LBPfeature';
save LBPfea LBPfea

% --- Executes on button press in gabor.
function gabor_Callback(hObject, eventdata, handles)
% hObject    handle to gabor (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global filt

preimg = filt;

Sx = 3; 
 Sy = 3; 
 L = 8; 
 f = [1/3.2,1/3.4,1/3.6,1/3.8]*2*pi; 
 p1 = ones(64,64); 
 level = graythresh(preimg);
 bw = im2bw(preimg,level); 
 [ival,jval] = find(bw==0); 
 imin = min(ival); 
 imax = max(ival); 
 jmin = min(jval); 
 jmax = max(jval); 
 bw1 = bw(imin:imax,jmin:jmax); 
 rate = 64/max(size(bw1)); 
 bw1 = imresize(bw1,rate); 
 [ival1,jval1] = size(bw1); 
 ir1 = round((64-ival1)/2); 
 jr1 = round((64-jval1)/2); 
 p1(ir1+1:ir1+ival1,jr1+1:jr1+jval1) = bw1; 
 p1 = double(p1); 
 m = 1;
 for fre=1:4 
     for iz=1:L 
            theta=(pi*iz)/8;
            for x = -fix(Sx):fix(Sx) 
                for y = -fix(Sy):fix(Sy) 
                    xPrime = x * cos(theta) + y * sin(theta); 
                    yPrime = y * cos(theta) - x * sin(theta); 
                    G(fix(Sx)+x+1,fix(Sy)+y+1) = exp(-.5*((xPrime/Sx)^2+(yPrime/Sy)^2))*cos(2*pi*f(1,fre)*xPrime); 
                end 
            end
            Imgabout = conv2( p1,double(imag(G)),'same'); 
            Regabout = conv2( p1,double(real(G)),'same'); 
            convim{m}=mat2gray(Regabout);
            m=m+1;
            imfea1(iz)=mean2(Imgabout);
            imfea2(iz)=mean2(Regabout);
            stfea1(iz)=std2(Imgabout);
            srfea2(iz)=std2(Regabout);
            medfea2(iz)=mean(var(Regabout)); 
     end
 end
 GABfea = [imfea2 srfea2 medfea2];
 save GABfea GABfea
 
for i=1:12
    figure(4);
    subplot(3,4,i),imshow(convim{i});axis off;title(['Gabor filter:',num2str(i)],'color','Black','fontname','Times New Roman','fontsize',11);
end


% --- Executes on button press in feature_extraction.
function feature_extraction_Callback(hObject, eventdata, handles)
% hObject    handle to feature_extraction (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
load LBPfea.Mat
load GABfea 
testfea = [LBPfea GABfea];
set(handles.uitable1,'data',testfea)
save testfea testfea


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main_gui

%% generate data


%% classify
load train1.mat
load target1.mat
load test1.mat



opts= struct;
opts.depth= 9;
opts.numTrees= 100;
opts.numSplits= 5;
opts.verbose= true;
opts.classifierID= 2; % weak learners to use. Can be an array for mix of weak learners too

tic;
m= forestTrain(train1, target1, opts);
timetrain= toc;
tic;
yhatTrain = forestTest(m, test1)

timetest= toc;


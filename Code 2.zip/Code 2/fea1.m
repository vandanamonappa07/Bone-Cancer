function fea1()
global  c f pink_osteiod dark_nuclie light_nuclie;
I=light_nuclie
im=wateralgo(I);
figure(2),imshow(light_nuclie), title('light nuclie');
%im=rgb2gray(I);

lev = graythresh(im); 
%imshow(ed);title('Canny Filter');
BW = im2bw(im,lev);
% label individual grains with different colors
[L,Number_reg] =  bwlabel(BW);
%figure(3),imshow(L);
count=Number_reg;
if(count<200)
LB = 5;
UB = 40;
Lout = xor(bwareaopen(L,LB),  bwareaopen(L,UB));
%figure(4),imshow(L);
%figure(5),imshow(Lout);
[L,Number_reg] =  bwlabel(Lout);
end
stats = regionprops(L,'Area','Perimeter');
area=[stats(:).Area];

%total_nuclie_area=sum(area);
%list= [stats(:).Perimeter];
%list=sort(list)
m_a=mean2(area);
s_a=std2(area);
%m_p=mean2(list);
%s_p=std2(list);

       if (m_a>s_a)
          pelo=0;
      else
          pelo=1;
      end
    if(count>300)
       mitotic_count=1;
       else
      mitotic_count=0;
     end
   
  if(pelo==1||mitotic_count==1)
      malignancy=1;
  elseif(pelo==0||mitotic_count==1)
  malignancy=1;
  elseif(pelo==1||mitotic_count==0)
       malignancy=0; 
  else
      malignancy=0; 
  end
     
         
   
         
    

 New_value={f,count,pelo,mitotic_count};
 %{
filename = 'new4.xlsx';
    %Check if you have created an Excel file previously or not 
     checkforfile=exist(strcat(pwd,'\','mitotic.xls'),'file');
     if checkforfile==0; % if not create new one
         header ={'File_name','Count','pelomormisim','Mitotic_count','Malignancy'};
         xlswrite('mitotic',header,'Sheetname','A1');
          N=0;
     else % if yes, count the number of previous inputs
          N=size(xlsread('mitotic','Sheetname'),1);
     end
% add the new values (your input) to the end of Excel file
 AA=strcat('A',num2str(N+2));
 BB=strcat('B',num2str(N+2));
 xlswrite('mitotic',filename,'Sheetname',AA);
 xlswrite('mitotic',New_value,'Sheetname',AA);
%}
 
 test1={count,pelo,mitotic_count};
  test1=cell2mat(test1(1,:)); % just a cell2mat
 save('test1.mat','test1');
end
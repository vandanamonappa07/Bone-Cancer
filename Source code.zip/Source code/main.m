% saran
% methods for nuclei detection
clc;
clear all;
close all;
% -------------------------------------------------------------------------
[f p] = uigetfile('*.jpg');
I=imread([p f]);
figure(1);
imshow(I);title('original Image');
% -------------------------------------------------------------------------
imres=imresize(I,[250 250]);
figure(2);
imshow(imres);title('Resized image');
% -------------------------------------------------------------------------
gr=rgb2gray(imres);
figure(3);
imshow(gr);title('Grayscale Image');
% -------------------------------------------------------------------------
filt=medfilt2(gr,[3 3]);
figure(4);
imshow(filt);title('Filtered image');
% -------------------------------------------------------------------------

% -------------------------------------------------------------------------

% [f p] = uigetfile('*.*');
% im = imread([p f]);
% % im =imread('1.jpg');
% figure
% imshow(I);
% title('Original INPUT Papsmear image')
im = double(I);
[back_masked_image] = separate_backgd(im,1);
figure;
imshow(uint8(back_masked_image.*im));
title('Backgroung Extraction');
watersd(uint8(back_masked_image.*im));





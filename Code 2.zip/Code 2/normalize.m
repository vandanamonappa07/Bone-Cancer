function varargout = normalize(varargin)
% NORMALIZE MATLAB code for normalize.fig
%      NORMALIZE, by itself, creates a new NORMALIZE or raises the existing
%      singleton*.
%
%      H = NORMALIZE returns the handle to a new NORMALIZE or the handle to
%      the existing singleton*.
%
%      NORMALIZE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NORMALIZE.M with the given input arguments.
%
%      NORMALIZE('Property','Value',...) creates a new NORMALIZE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before normalize_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to normalize_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help normalize

% Last Modified by GUIDE v2.5 07-Jan-2017 16:16:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @normalize_OpeningFcn, ...
                   'gui_OutputFcn',  @normalize_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before normalize is made visible.
function normalize_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to normalize (see VARARGIN)

% Choose default command line output for normalize
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes normalize wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = normalize_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global img  c f,
[name p] = uigetfile('*.jpg');
img=imread([p name]);
f=name;
img=imresize(img,[500 500]);
hist_matc=img;
hist_matc_max_lum=uint8(zeros(768,1024));
hist_matc_color_streched=hist_matc;
for i=1:500
  for j=1:500
        hist_matc_max_lum(i,j)=max(hist_matc(i,j,:)); % Takes the maximum value of the vector [r,g,b] as the intensity information
    end;
end;

u=hist_matc_max_lum;alpha=.9;beta=2.5;th_a=175;th_b=212;
[n_row,n_col]=size(u);
v=zeros(n_row,n_col);
u=double(u);

MAX_LUM=255; % Set up the maximum value for Y
MIN_U=min(min(u));
MAX_U=max(max(u));

v_o=-alpha*MIN_U;
v_a=alpha*(th_a)+v_o;
v_b=beta*(th_b-th_a)+v_a;
gamma=(MAX_LUM-v_b)/(MAX_U-th_b); % This is not a free parameter

for i=1:n_row
    for j=1:n_col
        if (u(i,j) < th_a)
            v(i,j)=alpha*(u(i,j))+v_o;
        elseif (u(i,j) >= th_a && u(i,j) < th_b )
            v(i,j)=beta*(u(i,j)-th_a)+v_a;
        elseif (u(i,j) >= th_b && u(i,j) <= MAX_LUM )
            v(i,j)=gamma*(u(i,j)-th_b)+v_b;
        else
            disp('ERROR: The input signal must take values between 0-255');
            return;
        end
    end
end
%v=uint8(v);

for i=1:500
    for j=1:500
        hist_matc_color_streched(i,j,:)=double(v(i,j))/max(double(hist_matc_max_lum(i,j)),eps)*double(hist_matc(i,j,:));
    end;
end;
c=hist_matc_color_streched;
axes(handles.axes1)
imshow(img),title('original Image');

axes(handles.axes2)
imshow(hist_matc_color_streched),title('color normalization');


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
main
function [I]=wateralgo(img)


F=im2double(img);



%Converting RGB image to Intensity Image
r=F(:,:,1);
g=F(:,:,2);
b=F(:,:,3);
I=(r+g+b)/3;
%imshow(I);

%Applying Gradient
hy = fspecial('sobel');
hx = hy';
Iy = imfilter(double(I), hy, 'replicate');
Ix = imfilter(double(I), hx, 'replicate');
gradmag = sqrt(Ix.^2 + Iy.^2);
%figure, imshow(gradmag,[]), title('Gradient magnitude (gradmag)');

L = watershed(gradmag);
Lrgb = label2rgb(L);
%figure, imshow(Lrgb), title('Watershed transform of gradient magnitude (Lrgb)');

end
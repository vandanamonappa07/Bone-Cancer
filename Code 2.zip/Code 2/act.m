[f p] = uigetfile('*.tif');
I=imread([p f]);
figure(7);imshow(I);
I=rgb2gray(I)
I=im2bw(I)
hold on;
boundaries = bwboundaries(I);
numberOfBoundaries = size(boundaries);
for k = 1 : numberOfBoundaries
	    thisBoundary= boundaries{k};
        pause(0.1)
        plot(thisBoundary(:,2), thisBoundary(:,1), 'g', 'LineWidth', 1);
end
figure(8),
imshow(imres);title('Countour Base Image Segment');
clc;
clear all;
close all;
[f p] = uigetfile('*.jpg');
 x=imread([p f]);
y=imresize(x,[350 350]);

[filename, pathname] = uiputfile(f, 'Save Picture as');
file=fullfile(pathname,filename)
imwrite(y,file);

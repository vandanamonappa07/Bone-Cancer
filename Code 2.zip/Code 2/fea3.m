function fea3()
global  c f pink_osteiod 
%-------------------------------calculation part---------------------
im=rgb2gray(pink_osteiod);
lev = graythresh(im); 
% apply threshold to segment light grains from dark background
BW = im2bw(im,lev);
[L,Number_reg] =  bwlabel(BW);
% label individual grains with different colors
LB = 100;
UB = 700;
Lout = xor(bwareaopen(L,LB),  bwareaopen(L,UB));
%figure(4),imshow(L);
%figure(5),imshow(Lout);
[L,Number_reg] =  bwlabel(Lout);

count=Number_reg
%figure;imshow(L);
stats = regionprops(L, 'Area');
area = [stats(:).Area];
total_nuclie_area_o=sum(area)

osteoid_deposite=0;
 if  (count>5 ||total_nuclie_area_o>1000) 
   osteoid_deposite=1;
 end

%{
 New_value={f,Number_reg,total_nuclie_area_o,osteoid_deposite};
 
 filename = 'new1.xlsx';
    %Check if you have created an Excel file previously or not 
     checkforfile=exist(strcat(pwd,'\','ost.xls'),'file');
     if checkforfile==0; % if not create new one
         header ={'File_name','Count','area','mean','std','osteoid production'};
         xlswrite('ost',header,'Sheetname','A1');
          N=0;
     else % if yes, count the number of previous inputs
          N=size(xlsread('ost','Sheetname'),1);
     end
% add the new values (your input) to the end of Excel file
 AA=strcat('A',num2str(N+2));
 BB=strcat('B',num2str(N+2));
 xlswrite('ost',filename,'Sheetname',AA);
 xlswrite('ost',New_value,'Sheetname',AA);
 %}
 
  test3={Number_reg,total_nuclie_area_o};
   test3=cell2mat(test3(1,:)); % just a cell2mat
 save('test3.mat','test3');
end

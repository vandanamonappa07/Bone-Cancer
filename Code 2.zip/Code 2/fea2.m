function fea2()
global  c f pink_osteiod dark_nuclie light_nuclie;
I=dark_nuclie
%figure(1),imshow(I);
im=wateralgo(I);
%im=rgb2gray(I);
lev = graythresh(im); 
BW = im2bw(im,lev);
%label individual grains with different colors
[L,Number_reg] =  bwlabel(BW);
%figure(2);imshow(L);
count=Number_reg;
if(count<150)
LB = 5;
UB = 140;
Lout = xor(bwareaopen(L,LB),  bwareaopen(L,UB));
%figure(3),imshow(L);
%figure(4),imshow(Lout);
[L,Number_reg] =  bwlabel(Lout);
end
stats = regionprops(L,'Area','Perimeter');

list= [stats(:).Perimeter];

m_p=mean2(list);
s_p=std2(list);

  
   if (m_p>s_p)
          pelo=0;
      else
          pelo=1;
   end
    if(count>200)
       hyper=1;
       else
      hyper=0;
     end
     if(pelo==1||hyper==1)
      malignancy=1;
  elseif(pelo==0||hyper==1)
  malignancy=1;
  elseif(pelo==1||hyper==0)
       malignancy=0; 
  else
      malignancy=0; 
  end
     

    
%{
 New_value={f,count,hyper,pelo,malignancy};
 
filename = 'new2.xlsx';
    %Check if you have created an Excel file previously or not 
     checkforfile=exist(strcat(pwd,'\','hyper.xls'),'file');
     if checkforfile==0; % if not create new one
         header ={'File_name','Count','hyper chromatic','mean','std','malignancy'};
         xlswrite('ost',header,'Sheetname','A1');
          N=0;
     else % if yes, count the number of previous inputs
          N=size(xlsread('hyper','Sheetname'),1);
     end
% add the new values (your input) to the end of Excel file
 AA=strcat('A',num2str(N+2));
 BB=strcat('B',num2str(N+2));
 xlswrite('hyper',filename,'Sheetname',AA);
 xlswrite('hyper',New_value,'Sheetname',AA);
%figure;imshow(L);
%}
  test2={count,hyper,pelo};
  test2=cell2mat(test2(1,:)); % just a cell2mat
 save('test2.mat','test2');
end